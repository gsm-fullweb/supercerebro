# ChatHook Backup

Backup tecnico recuperado do VPS do ChatHook em 2026-06-01.

## Origem

- VPS: `31.97.90.200`
- Stack Docker Swarm: `kanbanscript`
- Frontend: `astraonline/kanbanfront:develop`
- Backend: `kanbanscript_backend:ordered`

## Conteudo

- `PLANO_SELF_SERVICE.md`: plano para transformar o ChatHook em produto self-service.
- `chathook-package.json`: `package.json` recuperado do backend.
- `chathook-prisma/`: schema Prisma recuperado do backend.
- `chathook-backend-dist/`: backend compilado em producao.
- `chathook-frontend-html/`: build estatico/minificado do frontend em producao.

## Observacoes

- Este backup nao substitui o codigo-fonte original.
- O backend esta compilado e os source maps nao incluem o TypeScript original.
- O frontend esta minificado.
- Nao subir em repositorio publico.
- Antes de qualquer deploy, criar branch/projeto novo e testar fora de producao.

