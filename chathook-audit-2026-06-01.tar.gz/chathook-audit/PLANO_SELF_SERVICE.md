# Plano de Self-Service do ChatHook

Data: 2026-06-01

## Situacao Encontrada

- Nao existe repositorio GitHub/GitLab informado pelo Richard.
- O ChatHook esta rodando em Docker Swarm no VPS `31.97.90.200`.
- Backend em producao: `kanbanscript_backend:ordered`.
- Frontend em producao: `astraonline/kanbanfront:develop`.
- O backend tem arquivos compilados em `/app/dist`, `package.json` e `prisma/schema.prisma`.
- O frontend tem apenas build estatico/minificado em `/usr/share/nginx/html`.
- Os source maps do backend nao incluem `sourcesContent`; eles indicam nomes dos arquivos originais, mas nao trazem o codigo TypeScript completo.
- Nao foi encontrado codigo-fonte original do frontend/backend no VPS.

## O Que Ja Existe

O backend ja tem uma rota util para ativacao:

- `GET /api/quick-start/inboxes`
- `POST /api/quick-start`

Essa rota ja permite iniciar uma conversa de teste usando Chatwoot/WAHA/UAZAPI/Evolution, o que conversa diretamente com a etapa "Teste Guiado" da trilha.

O frontend ja tem rotas principais:

- `/`
- `/funnels`
- `/conexoes`
- `/chats`
- `/admin/setup`
- `/campaigns`
- `/chatbot`
- outras rotas operacionais

Ainda nao existe rota `/setup` no frontend atual.

## Risco Tecnico

Implementar direto em cima do container de producao e inseguro porque:

- nao ha fonte original versionada;
- frontend esta minificado;
- backend esta compilado;
- qualquer alteracao direta no container pode ser perdida em redeploy;
- alterar stack/servicos sem pipeline pode derrubar producao.

## Caminho Recomendado

### Fase 1 - Recuperacao e Versionamento

1. Criar um repositorio privado novo para o ChatHook.
2. Separar em dois projetos:
   - `backend`
   - `frontend`
3. Usar o que foi recuperado do VPS como referencia de producao:
   - `chathook-backend-dist`
   - `chathook-prisma`
   - `chathook-package.json`
   - `chathook-frontend-html`
4. Reconstruir o frontend com base nas rotas atuais e no bundle existente.
5. Reconstruir o backend a partir da estrutura Express/Prisma atual, usando os arquivos compilados como referencia.

### Fase 2 - MVP Self-Service

1. Criar rota `/setup`.
2. Criar checklist lateral:
   - Empresa configurada
   - WhatsApp conectado
   - Kanban criado
   - Teste enviado
   - Primeiro card criado
   - Equipe convidada
3. Reusar endpoints existentes quando possivel:
   - `/api/connections/*`
   - `/api/funnels`
   - `/api/quick-start`
4. Criar apenas os endpoints que faltarem:
   - `GET /api/onboarding/status`
   - `POST /api/onboarding/company`
   - `POST /api/onboarding/complete-step`
5. Adicionar tabela `onboarding_progress`.

### Fase 3 - Deploy Seguro

1. Gerar novas imagens Docker com tag versionada.
2. Subir primeiro em ambiente paralelo ou stack de teste.
3. Testar login, Kanban, conexoes WhatsApp, Chatwoot e quick-start.
4. Trocar a stack de producao somente depois dos testes.

## Proxima Acao Tecnica

Antes de qualquer mudanca em producao:

1. Criar backup/export do estado atual da stack.
2. Criar um repositorio base versionado.
3. Documentar comandos de rollback.
4. Implementar `/setup` em branch/projeto separado.

